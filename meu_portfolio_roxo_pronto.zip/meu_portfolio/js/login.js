// Login apenas para a simulação do projeto escolar.
// Em um site real, usuário e senha não devem ficar expostos no JavaScript.

const LOGIN_USER = "admin";
const LOGIN_PASSWORD = "1234";

const loginForm = document.getElementById("login-form");

if (loginForm) {
  loginForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    const message = document.getElementById("login-message");

    if (username === LOGIN_USER && password === LOGIN_PASSWORD) {
      sessionStorage.setItem("portfolioLogged", "true");
      window.location.href = "dashboard.html";
    } else {
      message.textContent = "Usuário ou senha incorretos. Tente novamente.";
    }
  });
}