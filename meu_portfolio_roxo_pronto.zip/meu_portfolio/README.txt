PORTFÓLIO PESSOAL - COMO USAR

1. Abra a pasta "meu_portfolio" no VS Code.
2. Abra o arquivo index.html com o Live Server.
3. O cadeado leva para login.html.
4. Login da simulação:
   usuário: admin
   senha: 1234
5. Depois do login, o dashboard permite cadastrar projetos.
6. Os projetos ficam salvos no localStorage do navegador e aparecem em portfolio.html.

IMPORTANTE:
- Troque a foto de exemplo por sua própria foto e mantenha o nome do arquivo como foto.webp.
- Troque os links de Instagram/GitHub e o e-mail pelos seus.
- Reescreva os textos das 5 sections com suas próprias palavras, porque o professor orienta que o texto final seja do aluno.
- O login em JavaScript é apenas uma simulação escolar; não é seguro para um sistema real.
